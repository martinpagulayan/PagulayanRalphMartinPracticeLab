package com.pagulayan;
import java.util.ArrayList;
import java.util.List;	

public class Carwash {
	private String car;
	private int showerDuration;
	private double carShampoo;
	private String postWashing;
	private String dryCar;
	private int vacuumDuration;
	private String tires; 
	private int userPayment;

	public Carwash() {

	}

	public Carwash(String car, int showerDuration, double carShampoo, String postWashing, String dryCar, int vacuumDuration, String tires, int userPayment) {
		this.car = car;
		this.showerDuration = showerDuration;
		this.carShampoo = carShampoo;
		this.postWashing = postWashing;
		this.dryCar = dryCar;
		this.vacuumDuration = vacuumDuration;
		this.tires = tires;
		this.userPayment = userPayment;
	}
	public void getCar(String car) {
		this.car = car;
	}
	public void getShowerDuration(int showerDuration) {
		this.showerDuration = showerDuration;
	}
	public void getShampooLiter(double carShampoo) {
		this.carShampoo = carShampoo;
	}
	public void getWashing(String postWashing) {
		this.postWashing = postWashing;
	}
	public void getDryCar(String dryCar) {
		this.dryCar = dryCar;
	}
	public void getVacuumDuration(int vacuumDuration) {
		this.vacuumDuration = vacuumDuration;
	}
	public void getTires(String tires) {
		this.tires = tires;
	}
	public void getPayment(int userPayment) {
		this.userPayment = userPayment;
	}
	public String setCar() {
		return this.car;
	}
	public int setShowerTime() {
		return this.showerDuration;
	}
	public double setShampoo() {
		return this.carShampoo;
	}
	public String setWash() {
		return this.postWashing;
	}
	public String setDry() {
		return this.dryCar;
	}
	public int setVacuumTime() {
		return this.vacuumDuration;
	}
	public String setTires() {
		return this.tires;
	}
	public int setPayment() {
		return this.userPayment;
	}
	public int pay(int pay1, int pay2, int pay3) {
		return pay1 + pay2 + pay3;
	}
}